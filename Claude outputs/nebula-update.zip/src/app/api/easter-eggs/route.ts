import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { EASTER_EGGS } from "@/lib/easter-eggs-registry";
import { markEasterEggFound } from "@/lib/easter-eggs/server";

export const dynamic = "force-dynamic";

// GET /api/easter-eggs — l'état complet des easter eggs pour le compte
// connecté : utilisé par la page /succes (onglet "Succès") et par le petit
// compteur affiché dans la Communauté. Le titre/indice n'est renvoyé QUE pour
// les eggs déjà trouvés — les autres ne remontent que leur numéro, pour ne
// rien dévoiler côté réseau (voir l'onglet Succès, qui les affiche en "?").
// Exception : le NOM de la récompense (`reward`) est lui renvoyé même pour
// un egg pas encore trouvé — c'est ce qui permet à /succes d'afficher
// "🎁 Récompense à la clé : ..." sans dévoiler comment l'obtenir.
export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({
      total: EASTER_EGGS.length,
      foundCount: 0,
      eggs: EASTER_EGGS.map((e) => ({ number: e.number, found: false, reward: e.reward }))
    });
  }

  const userId = (session.user as { id: string }).id;

  // Easter egg "Premier anniversaire personnel" : vérifié ICI plutôt que
  // sur une tâche planifiée — cette route est déjà appelée à chaque visite
  // de /succes ou de la Communauté (voir eggCount côté client), ce qui
  // couvre la grande majorité des sessions actives sans plomberie
  // supplémentaire. Compromis documenté : un compte qui ne visite ni l'une
  // ni l'autre ce jour-là ne recevra pas l'egg le jour précis.
  const me = await prisma.user.findUnique({ where: { id: userId }, select: { createdAt: true } });
  if (me) {
    const now = new Date();
    const created = me.createdAt as Date;
    if (now.getMonth() === created.getMonth() && now.getDate() === created.getDate() && now.getFullYear() > created.getFullYear()) {
      await markEasterEggFound(userId, "account-anniversary");
    }
  }

  // Types explicites : le client Prisma généré dans ce sandbox n'a pas accès
  // au réseau (voir schema.prisma), donc `findMany` ne renvoie pas de type
  // concret ici — sans cette annotation, `f` et `foundAt` tombent sur `{}`.
  const found: { key: string; foundAt: Date }[] = await prisma.easterEggFound.findMany({
    where: { userId },
    select: { key: true, foundAt: true }
  });
  const foundByKey = new Map<string, Date>(found.map((f) => [f.key, f.foundAt]));

  const eggs = EASTER_EGGS.map((e) => {
    const foundAt = foundByKey.get(e.key);
    if (!foundAt) return { number: e.number, found: false, reward: e.reward };
    return {
      number: e.number,
      found: true,
      key: e.key,
      emoji: e.emoji,
      title: e.title,
      hint: e.hint,
      reward: e.reward,
      foundAt: foundAt.toISOString()
    };
  });

  return NextResponse.json({ total: EASTER_EGGS.length, foundCount: found.length, eggs });
}
