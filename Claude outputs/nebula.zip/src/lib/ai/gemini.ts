// Client pour l'API Gemini (Google AI Studio) — https://ai.google.dev
//
// Choisi pour son palier gratuit réel (contrairement à l'API Anthropic ou
// OpenAI, payantes dès la première requête), ce qui compte tant que Nebula
// ne génère pas de revenu. Toute la couche IA est OPTIONNELLE : sans
// GEMINI_API_KEY dans .env, `isAiEnabled()` renvoie false et l'UI masque
// simplement les boutons IA — zéro coût, zéro obligation.
//
// Clé gratuite : https://aistudio.google.com/apikey

const API_BASE = "https://generativelanguage.googleapis.com/v1beta";
// Google retire régulièrement les anciens modèles (gemini-2.5-flash a été
// retiré pour les nouvelles clés le 19/09/2026, remplacé par gemini-3.6-flash
// — message d'erreur retourné directement par l'API). Si ça se reproduit,
// pas besoin de redéployer le code : réglez simplement GEMINI_MODEL (ou
// GEMINI_IMAGE_MODEL) dans les variables d'environnement Vercel avec le nom
// du nouveau modèle indiqué par l'erreur.
const DEFAULT_MODEL = process.env.GEMINI_MODEL || "gemini-3.6-flash";
// Modèle avec génération d'image (utilisé uniquement pour les miniatures IA).
const IMAGE_MODEL = process.env.GEMINI_IMAGE_MODEL || "gemini-2.5-flash-image";

export function isAiEnabled(): boolean {
  return Boolean(process.env.GEMINI_API_KEY);
}

function requireKey(): string {
  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    throw new Error(
      "GEMINI_API_KEY manquant. Obtenez une clé gratuite sur aistudio.google.com/apikey et ajoutez-la à .env pour activer les fonctions IA."
    );
  }
  return key;
}

export interface ChatMessage {
  role: "user" | "model";
  text: string;
}

interface GenerateContentPart {
  text?: string;
  inline_data?: { mime_type: string; data: string };
}

async function callGemini(params: {
  contents: { role: string; parts: GenerateContentPart[] }[];
  systemInstruction?: string;
  jsonMode?: boolean;
  model?: string;
}): Promise<string> {
  const key = requireKey();
  const model = params.model || DEFAULT_MODEL;

  const body: Record<string, unknown> = {
    contents: params.contents,
    generationConfig: {
      temperature: 0.8,
      maxOutputTokens: 1024,
      ...(params.jsonMode ? { responseMimeType: "application/json" } : {})
    }
  };
  if (params.systemInstruction) {
    body.systemInstruction = { role: "system", parts: [{ text: params.systemInstruction }] };
  }

  const res = await fetch(`${API_BASE}/models/${model}:generateContent?key=${key}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data?.error?.message || `Erreur Gemini (${res.status})`);
  }

  const text = data?.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ?? "";
  if (!text) throw new Error("Gemini n'a renvoyé aucun contenu (réponse peut-être filtrée).");
  return text;
}

/** Chat assistant général : aide à l'usage du site + analyse des stats fournies en contexte. */
export async function chatComplete(messages: ChatMessage[], systemInstruction: string): Promise<string> {
  return callGemini({
    systemInstruction,
    contents: messages.map((m) => ({ role: m.role, parts: [{ text: m.text }] }))
  });
}

/**
 * Génère un titre ou une description/légende adaptée à un réseau donné.
 * Quand une frame/image réelle du média est fournie (frameBase64), Gemini
 * la reçoit directement (vision) et doit s'appuyer STRICTEMENT sur ce qui y
 * est visible — sans ça (mediaHint texte seul, ex: "vidéo"), le modèle n'a
 * aucune idée du contenu réel et tend à halluciner un texte générique de
 * marque plutôt que de décrire la publication elle-même.
 */
export async function generateCopy(input: {
  field: "title" | "description";
  network?: string;
  maxLength?: number;
  brandName: string;
  existingTitle?: string;
  existingCaption?: string;
  mediaHint?: string; // ex: "vidéo" — utilisé seulement en repli si aucune image n'a pu être extraite
  frameBase64?: string;
  frameMimeType?: string;
}): Promise<string> {
  const { field, network, maxLength, brandName, existingTitle, existingCaption, mediaHint, frameBase64, frameMimeType } = input;

  const promptLines = [
    `Tu es un assistant de community management pour la marque "${brandName}" sur Nebula.`,
    frameBase64
      ? "Voici une image réelle extraite du média que la personne s'apprête à publier. Base-toi STRICTEMENT sur ce que tu vois (sujet, action, décor, ambiance) : n'invente rien qui ne soit pas visible sur cette image, et ne rédige surtout pas un texte de présentation générique de la marque."
      : mediaHint
        ? `Média joint : ${mediaHint} (aucune image n'a pu être analysée cette fois — reste prudent et générique sur le contenu visuel plutôt que d'inventer des détails).`
        : "",
    field === "title"
      ? `Rédige UN SEUL titre accrocheur (sans guillemets, sans hashtag) pour cette publication${network ? ` sur ${network}` : ""}.`
      : `Rédige UNE SEULE description/légende engageante${network ? ` adaptée à ${network}` : ""}, avec 2-3 hashtags pertinents à la fin.`,
    maxLength ? `Reste sous ${maxLength} caractères.` : "",
    existingTitle ? `Titre actuel (à améliorer, pas juste reformuler) : ${existingTitle}` : "",
    existingCaption ? `Description actuelle / contexte : ${existingCaption}` : "",
    "Réponds uniquement avec le texte final, sans préambule ni explication."
  ].filter(Boolean);

  const parts: GenerateContentPart[] = [{ text: promptLines.join("\n") }];
  if (frameBase64 && frameMimeType) {
    parts.push({ inline_data: { mime_type: frameMimeType, data: frameBase64 } });
  }

  const text = await callGemini({ contents: [{ role: "user", parts }] });
  return text.trim().replace(/^"|"$/g, "");
}

/**
 * Version "grand public" de generateCopy(), utilisée par le générateur
 * gratuit sans compte (/outils/legendes, voir /api/public/tools/captions).
 * Différence clé : ici on ne décrit jamais un média réel (le visiteur n'a
 * rien uploadé) mais un simple SUJET tapé au clavier — le prompt doit donc
 * traiter ce texte comme le sujet de la publication, pas comme la légende
 * d'un fichier joint, sans quoi Gemini comprend de travers (voir le
 * "Média joint : ..." de generateCopy, qui suppose toujours un fichier).
 */
export async function generateFreeCaption(input: {
  field: "title" | "description";
  network?: string;
  maxLength?: number;
  brandName: string;
  topic: string;
}): Promise<string> {
  const { field, network, maxLength, brandName, topic } = input;

  const promptLines = [
    `Tu es un assistant de community management qui aide "${brandName}" à rédiger une publication.`,
    `Sujet de la publication, décrit par la personne : ${topic}`,
    field === "title"
      ? `Rédige UN SEUL titre accrocheur (sans guillemets, sans hashtag) pour cette publication${network ? ` sur ${network}` : ""}.`
      : `Rédige UNE SEULE description/légende engageante${network ? ` adaptée à ${network}` : ""}, avec 2-3 hashtags pertinents à la fin.`,
    maxLength ? `Reste sous ${maxLength} caractères.` : "",
    "Réponds uniquement avec le texte final, sans préambule ni explication."
  ].filter(Boolean);

  const text = await callGemini({ contents: [{ role: "user", parts: [{ text: promptLines.join("\n") }] }] });
  return text.trim().replace(/^"|"$/g, "");
}

export interface FrameCandidate {
  index: number;
  base64: string;
  mimeType: string;
}

/**
 * Fait choisir à Gemini les meilleures frames parmi plusieurs candidates
 * extraites d'une même vidéo, pour la génération de miniatures (voir
 * "Générer des miniatures" dans composer/page.tsx) — évite de proposer des
 * frames de transition, floues ou sans intérêt visuel qui sortiraient d'un
 * simple échantillonnage à intervalles fixes.
 */
export async function pickBestFrames(input: { frames: FrameCandidate[]; count: number }): Promise<number[]> {
  const { frames, count } = input;
  const promptText = [
    "Tu es un directeur artistique qui choisit la meilleure image de couverture (miniature) parmi plusieurs frames extraites de la même vidéo, numérotées dans l'ordre chronologique (index 0 à " +
      (frames.length - 1) +
      ").",
    "Choisis celles qui feraient les meilleures miniatures : nettes (pas de flou de mouvement), bien cadrées, sujet principal clairement visible et reconnaissable, moment ou expression engageant. Évite les frames de transition, noires, floues, ou sans intérêt visuel.",
    `Réponds STRICTEMENT en JSON avec ce format : {"bestIndexes": [index1, index2, ...]}, en donnant jusqu'à ${count} indices, du meilleur au moins bon.`
  ].join("\n");

  const parts: GenerateContentPart[] = [{ text: promptText }];
  for (const frame of frames) {
    parts.push({ text: `Frame index ${frame.index} :` });
    parts.push({ inline_data: { mime_type: frame.mimeType, data: frame.base64 } });
  }

  const raw = await callGemini({ contents: [{ role: "user", parts }], jsonMode: true });
  try {
    const parsed = JSON.parse(raw);
    const indexes: number[] = Array.isArray(parsed.bestIndexes)
      ? parsed.bestIndexes.filter((n: unknown): n is number => typeof n === "number")
      : [];
    return indexes.slice(0, count);
  } catch {
    return [];
  }
}

export interface GeneratedThumbnail {
  base64: string;
  mimeType: string;
}

/**
 * Génère une miniature "punchy" à partir d'une frame réelle de la vidéo
 * (extraite côté navigateur, sans ffmpeg — voir composer/page.tsx) : Gemini
 * reçoit l'image et un prompt lui demandant de la rendre plus accrocheuse
 * (contraste, cadrage, éventuellement un court texte d'accroche), et renvoie
 * une image générée qu'on propose comme option de miniature parmi d'autres.
 */
export async function generateThumbnail(input: {
  frameBase64: string;
  frameMimeType: string;
  title: string;
  network?: string;
}): Promise<GeneratedThumbnail> {
  const key = requireKey();
  const prompt = [
    "Tu vas créer une miniature vidéo accrocheuse à partir de cette image, extraite d'une vraie vidéo.",
    `Titre de la vidéo : "${input.title || "sans titre"}"${input.network ? ` (réseau : ${input.network})` : ""}.`,
    "Garde le sujet principal de l'image reconnaissable, mais rends le cadrage et le contraste plus percutants,",
    "façon miniature YouTube/TikTok qui donne envie de cliquer. Tu peux ajouter un très court texte d'accroche",
    "à l'écran si ça sert l'image, mais reste sobre et lisible. Format 16:9."
  ].join(" ");

  const res = await fetch(`${API_BASE}/models/${IMAGE_MODEL}:generateContent?key=${key}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [
        {
          role: "user",
          parts: [{ text: prompt }, { inline_data: { mime_type: input.frameMimeType, data: input.frameBase64 } }]
        }
      ]
    })
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data?.error?.message || `Erreur Gemini (${res.status})`);
  }

  const parts: GenerateContentPart[] = data?.candidates?.[0]?.content?.parts ?? [];
  const imagePart = parts.find((p) => p.inline_data?.data);
  if (!imagePart?.inline_data) {
    throw new Error("Gemini n'a renvoyé aucune image (le modèle de génération d'image est peut-être indisponible).");
  }
  return { base64: imagePart.inline_data.data, mimeType: imagePart.inline_data.mime_type || "image/png" };
}

/**
 * Génère un sticker/emoji exclusif Premium à partir d'un simple prompt texte
 * (pas d'image en entrée, contrairement à generateThumbnail) — utilisé par
 * /api/premium/reactions/generate pour fabriquer le pack "Or Impérial".
 * Demande un rendu carré, fond transparent, cohérent avec les autres
 * réactions du pack (voir le prompt de style ci-dessous).
 */
export async function generateStickerPack(input: { prompt: string }): Promise<GeneratedThumbnail> {
  const key = requireKey();
  const prompt = [
    "Crée un sticker/emoji numérique unique représentant :",
    input.prompt + ".",
    "Style : icône moderne en dégradé d'or scintillant, finition glossy/néon liquide, cohérente avec un thème",
    "'Premium doré' haut de gamme. Cadrage carré, sujet centré et bien visible, fond transparent ou uni sombre",
    "(pas de texte, pas de fond photographique). Le résultat doit ressembler à un emoji/sticker autonome,",
    "utilisable en petite taille (comme une réaction sur un réseau social)."
  ].join(" ");

  const res = await fetch(`${API_BASE}/models/${IMAGE_MODEL}:generateContent?key=${key}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: prompt }] }]
    })
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data?.error?.message || `Erreur Gemini (${res.status})`);
  }

  const parts: GenerateContentPart[] = data?.candidates?.[0]?.content?.parts ?? [];
  const imagePart = parts.find((p) => p.inline_data?.data);
  if (!imagePart?.inline_data) {
    throw new Error("Gemini n'a renvoyé aucune image (le modèle de génération d'image est peut-être indisponible).");
  }
  return { base64: imagePart.inline_data.data, mimeType: imagePart.inline_data.mime_type || "image/png" };
}

export interface FrameInput {
  timeRatio: number; // 0..1, position dans la vidéo
  base64: string;
  mimeType: string;
}

export interface RetentionPoint {
  timeRatio: number;
  watchRatio: number;
}

export interface VideoAnalysis {
  summary: string;
  dropOffPoints: { timeRatio: number; watchRatio: number; note: string }[];
  recommendations: string[];
}

/**
 * Analyse la rétention d'une vidéo à la manière du "YouTube Studio AI
 * Insights" : on fournit à Gemini la vraie courbe de rétention (récupérée
 * via YouTube Analytics API, voir src/lib/social/youtube.ts::fetchRetention)
 * ainsi que des frames extraites de la vidéo aux points de décrochage
 * (ffmpeg, voir src/lib/video/frames.ts). Gemini "regarde" ces images et
 * corrèle avec la courbe pour expliquer ce qui se passe à l'écran à ces
 * instants et ce qu'il faudrait changer.
 */
export async function analyzeVideoRetention(input: {
  title: string;
  caption: string;
  retentionCurve: RetentionPoint[];
  frames: FrameInput[];
}): Promise<VideoAnalysis> {
  const { title, caption, retentionCurve, frames } = input;

  const curveDescription = retentionCurve
    .map((p) => `t=${Math.round(p.timeRatio * 100)}% → ${Math.round(p.watchRatio * 100)}% de spectateurs restants`)
    .join("\n");

  const promptText = [
    "Tu es un analyste de performance vidéo, comme l'assistant IA de YouTube Studio.",
    `Titre de la vidéo : ${title}`,
    `Description : ${caption}`,
    "Voici la courbe réelle de rétention d'audience (donnée par YouTube Analytics) :",
    curveDescription,
    "Voici des images extraites de la vidéo aux instants correspondant aux plus grosses chutes de rétention (dans l'ordre des frames fournies, timeRatio croissant).",
    "Analyse ce qui se passe visuellement à ces moments et pourquoi les spectateurs partent probablement.",
    "Réponds STRICTEMENT en JSON avec ce format :",
    `{"summary": "résumé en 2-3 phrases", "dropOffPoints": [{"timeRatio": 0.0-1.0, "watchRatio": 0.0-1.0, "note": "explication du décrochage à ce moment, basée sur l'image"}], "recommendations": ["conseil actionnable 1", "conseil actionnable 2", "..."]}`
  ].join("\n\n");

  const parts: GenerateContentPart[] = [{ text: promptText }];
  for (const frame of frames) {
    parts.push({ inline_data: { mime_type: frame.mimeType, data: frame.base64 } });
  }

  const raw = await callGemini({ contents: [{ role: "user", parts }], jsonMode: true });
  try {
    const parsed = JSON.parse(raw);
    return {
      summary: parsed.summary ?? "",
      dropOffPoints: Array.isArray(parsed.dropOffPoints) ? parsed.dropOffPoints : [],
      recommendations: Array.isArray(parsed.recommendations) ? parsed.recommendations : []
    };
  } catch {
    return { summary: raw, dropOffPoints: [], recommendations: [] };
  }
}

/**
 * Version "chaîne entière" de analyzeVideoRetention(), utilisée par l'outil
 * autonome /retention (voir produit n°3 de la feuille de route) : contraint
 * à la miniature publique de la vidéo (via l'API YouTube Data) plutôt qu'à
 * des frames extraites au ffmpeg aux instants de décrochage, car on n'a pas
 * forcément le fichier vidéo source stocké dans Nebula (vidéo publiée
 * ailleurs, ou importée avant l'existence de l'outil). Volontairement plus
 * prudent dans le prompt : Gemini n'a qu'UNE SEULE image (la miniature, pas
 * le contenu réel à chaque seconde), donc ses observations "visuelles" sont
 * cadrées comme des hypothèses à vérifier, pas des faits établis — pour ne
 * jamais donner l'impression d'avoir "vu" un instant qu'il n'a pas vu.
 */
export async function analyzeVideoRetentionByThumbnail(input: {
  title: string;
  description: string;
  retentionCurve: RetentionPoint[];
  thumbnailBase64: string;
  thumbnailMimeType: string;
}): Promise<VideoAnalysis> {
  const { title, description, retentionCurve, thumbnailBase64, thumbnailMimeType } = input;

  const curveDescription = retentionCurve
    .map((p) => `t=${Math.round(p.timeRatio * 100)}% → ${Math.round(p.watchRatio * 100)}% de spectateurs restants`)
    .join("\n");

  const promptText = [
    "Tu es un analyste de performance vidéo YouTube, comme l'assistant IA de YouTube Studio.",
    `Titre de la vidéo : ${title}`,
    `Description : ${description || "(aucune)"}`,
    "Voici la courbe RÉELLE de rétention d'audience (donnée par YouTube Analytics) :",
    curveDescription,
    "Tu ne disposes que de la miniature publique de la vidéo (image jointe) — PAS des images du contenu à chaque instant. Base tes hypothèses sur le titre, la description, la forme de la courbe (chute brutale au début = accroche faible, décrochage progressif = rythme qui s'essouffle, plateau = contenu qui retient bien...) et ce que suggère la miniature, sans jamais prétendre avoir vu ce qui se passe réellement à l'écran à un instant précis.",
    "Réponds STRICTEMENT en JSON avec ce format :",
    `{"summary": "résumé en 2-3 phrases", "dropOffPoints": [{"timeRatio": 0.0-1.0, "watchRatio": 0.0-1.0, "note": "hypothèse sur la cause probable de ce décrochage, formulée comme une hypothèse"}], "recommendations": ["conseil actionnable 1", "conseil actionnable 2", "..."]}`
  ].join("\n\n");

  const parts: GenerateContentPart[] = [
    { text: promptText },
    { inline_data: { mime_type: thumbnailMimeType, data: thumbnailBase64 } }
  ];

  const raw = await callGemini({ contents: [{ role: "user", parts }], jsonMode: true });
  try {
    const parsed = JSON.parse(raw);
    return {
      summary: parsed.summary ?? "",
      dropOffPoints: Array.isArray(parsed.dropOffPoints) ? parsed.dropOffPoints : [],
      recommendations: Array.isArray(parsed.recommendations) ? parsed.recommendations : []
    };
  } catch {
    return { summary: raw, dropOffPoints: [], recommendations: [] };
  }
}

/**
 * Idée de contenu pour une case vide du calendrier (voir bouton discret
 * "Proposer une idée IA" sur calendar/page.tsx). S'appuie sur la date réelle
 * (jour de la semaine + jour du mois, pour évoquer d'éventuels marronniers/
 * journées mondiales connus de Gemini) et le nom de la marque — reste un
 * texte court et actionnable, jamais une légende complète prête à publier.
 */
export async function generateContentIdea(input: { brandName: string; date: string }): Promise<string> {
  const dateObj = new Date(`${input.date}T12:00:00`);
  const formatted = dateObj.toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" });
  const prompt = [
    `Tu aides la marque "${input.brandName}" à ne pas laisser un jour de calendrier vide sur Nebula.`,
    `Nous sommes le ${formatted}.`,
    "Si cette date correspond à une journée mondiale/nationale connue, une tendance saisonnière ou un marronnier marketing pertinent, appuie-toi dessus. Sinon, propose une idée de publication générique mais concrète adaptée à une marque active sur les réseaux sociaux.",
    "Réponds en 1 à 2 phrases maximum : une idée de contenu concrète et actionnable (pas un titre, pas de hashtags, pas de guillemets), que la personne pourra ensuite rédiger elle-même dans le compositeur."
  ].join("\n");
  const text = await callGemini({ contents: [{ role: "user", parts: [{ text: prompt }] }] });
  return text.trim().replace(/^"|"$/g, "");
}

export interface RepurposedContent {
  instagramReel: string;
  facebookPost: string;
  tiktokScript: string;
}

/**
 * Recyclage de contenu automatisé (Auto-Repurpose) : à partir d'un contenu
 * source (typiquement une vidéo/script YouTube déjà rédigé dans le
 * Composer), génère 3 déclinaisons textuelles adaptées à d'autres formats/
 * réseaux. Ne génère aucun média — uniquement le texte, à associer ensuite
 * manuellement au bon média dans le Composer.
 */
export async function repurposeContent(input: {
  brandName: string;
  sourceTitle: string;
  sourceCaption: string;
}): Promise<RepurposedContent> {
  const prompt = [
    `Tu es un assistant de recyclage de contenu pour la marque "${input.brandName}" sur Nebula.`,
    `Contenu source (ex : vidéo YouTube) — Titre : ${input.sourceTitle || "(sans titre)"}`,
    `Description/script source : ${input.sourceCaption || "(vide)"}`,
    "À partir de ce contenu, génère 3 déclinaisons distinctes, chacune adaptée à son format :",
    "1. instagramReel : une légende courte et percutante pour un Reel Instagram reprenant le même sujet, avec 2-3 hashtags.",
    "2. facebookPost : un post Facebook un peu plus détaillé/conversationnel sur le même sujet.",
    "3. tiktokScript : un script court (accroche + 2-3 lignes clés) pour une vidéo TikTok sur le même sujet.",
    "Réponds STRICTEMENT en JSON avec ce format :",
    `{"instagramReel": "...", "facebookPost": "...", "tiktokScript": "..."}`
  ].join("\n");

  const raw = await callGemini({ contents: [{ role: "user", parts: [{ text: prompt }] }], jsonMode: true });
  try {
    const parsed = JSON.parse(raw);
    return {
      instagramReel: parsed.instagramReel ?? "",
      facebookPost: parsed.facebookPost ?? "",
      tiktokScript: parsed.tiktokScript ?? ""
    };
  } catch {
    return { instagramReel: raw, facebookPost: "", tiktokScript: "" };
  }
}
